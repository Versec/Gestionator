package es.ucm.fdi.aplicationservice;

import es.ucm.fdi.integracion.EstadoActual;
import es.ucm.fdi.integracion.TPedido;
import es.ucm.fdi.negocio.BusinessPedido;

public class GestionPedidos {
	
	private BusinessPedido BOPedido;
	public GestionPedidos(BusinessPedido BOPedido){
		this.BOPedido = BOPedido;
	}
	
	public Integer eliminar (String id) {
		Integer OK = -1;
		TPedido pedidoLeido = BOPedido.leer(id);
		if(pedidoLeido != null){
			if(pedidoLeido.getPControl().getEstadoActual() == EstadoActual.NOENVIADO){
				BOPedido.eliminar(id);
				OK = 1;
			}
			else OK = 0;
			
		}
		return OK;
		
		
	}

	
}
