package es.ucm.fdi.integracion;

public enum Localizacion {

	SUCURSAL_INICIO,
	SUCURSAL_INTERMEDIA,
	SUCURSAL_LLEGADA;
}
