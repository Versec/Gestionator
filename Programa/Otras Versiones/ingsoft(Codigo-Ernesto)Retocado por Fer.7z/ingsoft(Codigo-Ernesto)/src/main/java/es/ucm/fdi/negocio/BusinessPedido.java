package es.ucm.fdi.negocio;

import es.ucm.fdi.integracion.DAOPedido;
import es.ucm.fdi.integracion.TPedido;

public class BusinessPedido {
	
	private DAOPedido daoPedido;
	
	public BusinessPedido(DAOPedido daoPedido){
		this.daoPedido = daoPedido;
	}
	
	public void eliminar(String id) {
		this.daoPedido.eliminar(id);
		
	}
	
	public TPedido leer(String id) {
		return this.daoPedido.leer(id);
	}
}
