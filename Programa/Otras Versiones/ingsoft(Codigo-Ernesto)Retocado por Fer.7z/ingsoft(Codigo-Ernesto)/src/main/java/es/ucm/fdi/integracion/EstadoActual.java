package es.ucm.fdi.integracion;

public enum EstadoActual {
	NOENVIADO, REPARTO, ENTREGADO
}
