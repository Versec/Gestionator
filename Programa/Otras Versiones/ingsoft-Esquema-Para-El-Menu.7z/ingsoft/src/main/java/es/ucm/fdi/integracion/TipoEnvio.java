package es.ucm.fdi.integracion;

public enum TipoEnvio {
	URGENTE,
	NORMAL;
}
