package es.ucm.fdi.integracion;

import java.util.List;

import es.ucm.fdi.datos.BDMemoria;

public class DAOPedido implements DAO<TPedido>{

	
	private BDMemoria<TPedido> bdPedidos;
	
	public void add(TPedido dato) {
		// TODO Auto-generated method stub
		this.bdPedidos.insert(dato, dato.getId());
		
	}

	public boolean eliminar(String ID) {
		// TODO Auto-generated method stub
		return this.bdPedidos.removeId(ID);
	}

	public void actualizar(TPedido datoActualizado) {
		// TODO Auto-generated method stub
		this.bdPedidos.insert(datoActualizado, datoActualizado.getId());
	}

	public TPedido leer(String Id) {
		// TODO Auto-generated method stub
		return this.bdPedidos.find(Id);
	}

	public List<TPedido> leerTodos() {
		// TODO Auto-generated method stub
		return null;
	}

}
