package es.ucm.fdi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import es.ucm.fdi.datos.BDMemoria;
import es.ucm.fdi.integracion.DAO;
import es.ucm.fdi.integracion.DAOPedido;
import es.ucm.fdi.integracion.MetPago;
import es.ucm.fdi.integracion.TCliente;
import es.ucm.fdi.integracion.TEmpleado;
import es.ucm.fdi.integracion.TPControl;
import es.ucm.fdi.integracion.TPedido;
import es.ucm.fdi.integracion.TSucursal;
import es.ucm.fdi.integracion.TipoEnvio;
import excepciones.ArrayException;

public class Gestionator {

	public static void main(String[] args) {
		
		
		BDMemoria<TPedido> BD=new es.ucm.fdi.datos.BDMemoria<TPedido>();
		
		DAO daoPedido = new DAOPedido(BD);

	}

	
	
	private void llenarBd(BDMemoria<TPedido> BD ){
		//Por defecto el archivo a leer es datoGestionator.
		Scanner sc = new Scanner(new File("datoGestionator"));
        String s="";
		while(sc.hasNextLine()){
        	s=sc.nextLine();
        	String[] words = s.split(" +");
        	
		}
          BD.insert(nuevo, id);insert();
        sc.close();
    
	}
	
	
	
	
	private TPedido generarTPedido(String[] words){
		
		
		
		
		
		
		
		new TPedido(generarTCliente(words[1],Integer.parseInt(words[2])),
				generarTEmpleado(words[3],words[4],, boolean activo)
				,false,String receptor,String Id,MetPago metPago,
				TSucursal SucursalSalida,TSucursal SucursalLlegada,TipoEnvio tipoDeEnvio,TPControl puntoControl){
			
	}
	
		
	private TEmpleado generarTEmpleado(int Id,String nombre,String email, boolean activo){
		return new TEmpleado(Id, nombre,email,activo);
	}
		
	private TCliente generarTCliente(String nombre, int Id){
		return new TCliente(nombre, Id);
	}
	
	
	
	public void readFich(String fich) throws FileNotFoundException, ArrayException, IOException {
        
        this.sProgram.deleteAll();
        
	}
}