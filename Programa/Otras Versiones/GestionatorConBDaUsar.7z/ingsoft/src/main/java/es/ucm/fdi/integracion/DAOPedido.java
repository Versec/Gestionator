package es.ucm.fdi.integracion;

import java.util.List;

import es.ucm.fdi.datos.BDGestionator;
import es.ucm.fdi.datos.BDMemoria;

public class DAOPedido implements DAO<TPedido>{

	
	private BDGestionator<TPedido,TEmpleado> bdPedidos;
	
	
	public DAOPedido(BDGestionator<TPedido,TEmpleado> bd){
		this.bdPedidos=bd;
	}
	
	public void add(TPedido dato) {
		// TODO Auto-generated method stub
		this.bdPedidos.insertP(dato, dato.getId());
		
	}

	public boolean eliminar(String ID) {
		// TODO Auto-generated method stub
		return this.bdPedidos.removeIdP(ID);
	}

	public void actualizar(TPedido datoActualizado) {
		// TODO Auto-generated method stub
		this.bdPedidos.insertP(datoActualizado, datoActualizado.getId());
	}

	public TPedido leer(String Id) {
		// TODO Auto-generated method stub
		return this.bdPedidos.findP(Id);
	}

	public List<TPedido> leerTodos() {
		// TODO Auto-generated method stub
		return null;
	}

}
