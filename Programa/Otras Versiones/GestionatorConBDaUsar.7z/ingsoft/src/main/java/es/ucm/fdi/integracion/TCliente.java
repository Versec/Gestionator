package es.ucm.fdi.integracion;

public class TCliente {

	private String nombre;
	private int ID;
	
	
	
	public TCliente(String nombre, int ID){
		this.nombre=nombre;
		this.ID=ID;
	}
	
	
	public void setNombre(String nombre){
		this.nombre=nombre;
	}
	
	public void setID(int ID){
		this.ID=ID;
	}
	
	public int getID(){
		return this.ID;
	}
	
	public String getNombre(){
		return this.nombre;
	}
	
	
}
