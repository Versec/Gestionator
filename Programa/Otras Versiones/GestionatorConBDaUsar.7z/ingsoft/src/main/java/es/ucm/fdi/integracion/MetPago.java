package es.ucm.fdi.integracion;

public enum MetPago {
	TRASFERNCIA,
	CONTRA_REEMBOLSO;
}
