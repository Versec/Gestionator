package es.ucm.fdi.integracion;

public enum EstadoPedido {
	Almacen,
	Reparto,
	Perdido,
	Entregado
}
