package es.ucm.fdi.integracion;

public enum TipoDeEnvio {
	Normal,
	Urgente
}
