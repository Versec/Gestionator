package es.ucm.fdi.integracion;

public enum MetPago {
	TRANSFERENCIA,
	CONTRAREEMBOLSO;
}
