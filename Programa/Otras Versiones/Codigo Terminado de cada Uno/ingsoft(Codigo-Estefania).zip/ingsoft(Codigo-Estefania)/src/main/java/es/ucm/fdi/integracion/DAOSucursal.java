package es.ucm.fdi.integracion;

import java.util.List;

public class DAOSucursal implements DAO<TSucursal> 
{

	public void add(TSucursal dato, String cod) {
		// TODO Auto-generated method stub
		
	}

	public void eliminar(int ID) {
		// TODO Auto-generated method stub
		
	}

	public void actualizar(TSucursal datoActualizado) {
		// TODO Auto-generated method stub
		
	}

	public TSucursal leer(int Id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<TSucursal> leerTodos() {
		// TODO Auto-generated method stub
		return null;
	}

}
