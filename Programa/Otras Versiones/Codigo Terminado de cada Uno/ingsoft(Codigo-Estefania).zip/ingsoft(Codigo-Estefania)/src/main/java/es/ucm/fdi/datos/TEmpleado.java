package es.ucm.fdi.datos;

public class TEmpleado {
	public int id;
	public String nombre;
	public String eMail;
	public boolean activo;
	

}
