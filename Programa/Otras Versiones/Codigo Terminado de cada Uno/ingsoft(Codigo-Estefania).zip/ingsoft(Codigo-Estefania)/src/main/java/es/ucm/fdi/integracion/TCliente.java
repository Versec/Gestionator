package es.ucm.fdi.integracion;

public class TCliente {

	private String Nombre;
	private String DNI;
	private String  Direccion;
	
	
	public TCliente(String Nombre,String DNI,String Direccion)
	{
		this.Nombre = Nombre;
		this.DNI =DNI;
		this.Direccion = Direccion;
	}
	
	
	
}
