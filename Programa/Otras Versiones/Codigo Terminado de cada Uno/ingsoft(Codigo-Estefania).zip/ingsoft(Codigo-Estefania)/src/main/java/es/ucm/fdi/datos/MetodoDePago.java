package es.ucm.fdi.datos;

public enum MetodoDePago {
	Efectivo,
	Contrarembolso,
	Transferencia
}
