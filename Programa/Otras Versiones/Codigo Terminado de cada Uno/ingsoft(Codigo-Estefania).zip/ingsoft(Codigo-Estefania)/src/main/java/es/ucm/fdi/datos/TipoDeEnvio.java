package es.ucm.fdi.datos;

public enum TipoDeEnvio {
	Normal,
	Urgente
}
