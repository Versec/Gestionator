package es.ucm.fdi.negocio;

public class BuisnessPedido {

}
