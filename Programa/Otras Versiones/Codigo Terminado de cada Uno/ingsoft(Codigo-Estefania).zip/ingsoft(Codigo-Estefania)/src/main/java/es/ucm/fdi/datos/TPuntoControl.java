package es.ucm.fdi.datos;

public class TPuntoControl {

}
