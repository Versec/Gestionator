package es.ucm.fdi.interfaz;

import java.util.Scanner;

import es.ucm.fdi.aplicationservice.GestionPedidos;
import es.ucm.fdi.integracion.Localizacion;

public class ConsoleView {

	private Scanner leer;
	private GestionPedidos gestionPedidos;

	public ConsoleView(GestionPedidos gestionPedidos){
		this.leer=new Scanner(System.in);
		this.gestionPedidos = gestionPedidos;
	}
	
	
	public int menu(){
		int n=0;
		boolean goOut=false;
		System.out.println("0-Salir");
		System.out.println("1-Actualizar Pedido: ");
		System.out.println("2-Eliminar Pedido:   ");
		
		while(!goOut){
			String s = this.leer.nextLine();
			try{n=Integer.parseInt(s);
			
			//Segun el numero de acciones que tenga el menu, ajustar el rango.
			while(n >= 0 && n < 3 && !goOut){
				System.out.println("Error al seleccionar accion ");	
				 s = this.leer.nextLine();
				 n=Integer.parseInt(s);
				 if(n==0)
					 goOut=true;
				}
			}//Try
			catch(NumberFormatException e){
				System.out.println("Error, introduce un numero. ");
			}
			funcionSwitch(n);
		
		}
		
		return n;
	}
	
	
	
	public void funcionSwitch(int n){
		switch(n){
		case 0: System.exit(0);
		case 1: 
		case 2:
			if(eliminarPedido(ValidarID()) == 1)
				System.out.println("Pedido eliminado con exito. \n");
			else if(eliminarPedido(ValidarID()) == 0)
				System.out.println("Pedido en reparto o ya entregado, imposible de eliminar. \n");
			else 
				System.out.println("El pedido con el codigo introducido no existe. \n");
			break;
		case 3: 
		}
		
	}
	
	public String ValidarID(){
		System.out.print("Escribe el ID del pedido a buscar: ");
		String s = this.leer.nextLine();
		return s;
		
	}
	
	public boolean ValidarPControl(){
		
		System.out.print("Escribe el ID del pedido a buscar: ");
		String s = this.leer.nextLine();
		
		Localizacion lugar=ComprobarLocalizacion(s);
		
		return lugar==null ? false : true;
	}
	
	private Localizacion ComprobarLocalizacion(String s){
		boolean goOut=false;
		Localizacion loc=null;
		while( loc==null && !goOut){
			System.out.print("Error al introducir un valor de localizacion, "
					+ "vuelve a intentarlo o introduce un 0 para salir(que el 0 no tenga espacios): ");
			s = this.leer.nextLine();
			
			if(!s.equalsIgnoreCase("0"))
				goOut=true;
			else
				loc=Localizacion.StringToLocalizacion(s);
		}
		
		
		return goOut ? null: loc;
	}
	
	public Integer eliminarPedido(String id){
		return this.gestionPedidos.eliminar(id);
		
	}
	
}
