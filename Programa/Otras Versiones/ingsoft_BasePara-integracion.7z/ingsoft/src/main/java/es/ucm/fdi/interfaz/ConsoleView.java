package es.ucm.fdi.interfaz;

public class ConsoleView {

}
