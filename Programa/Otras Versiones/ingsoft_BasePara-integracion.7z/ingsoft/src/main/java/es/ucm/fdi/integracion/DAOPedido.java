package es.ucm.fdi.integracion;

import java.util.List;

public class DAOPedido implements DAO<TPedido>{

	public void add(TPedido dato) {
		// TODO Auto-generated method stub
		
	}

	public void eliminar(int ID) {
		// TODO Auto-generated method stub
		
	}

	public void actualizar(TPedido datoActualizado) {
		// TODO Auto-generated method stub
		
	}

	public TPedido leer(int Id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<TPedido> leerTodos() {
		// TODO Auto-generated method stub
		return null;
	}

}
