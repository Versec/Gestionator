package es.ucm.fdi.negocio;

import es.ucm.fdi.integracion.DAOSucursal;
import es.ucm.fdi.integracion.TSucursal;

public class BusinessSucursal {

	
	
	private DAOSucursal daoSucursal;
	
	
	public BusinessSucursal(DAOSucursal daoSucursal){
		this.daoSucursal=daoSucursal;
	}
	
	public void eliminar(String id) {
		this.daoSucursal.eliminar(id);
		
	}
	
	public void Añadir(TSucursal ped,String id) {
		this.daoSucursal.add(ped, id);
		
	}
	
	public TSucursal leer(String id) {
		return this.daoSucursal.leer(id);
	}
	

}
